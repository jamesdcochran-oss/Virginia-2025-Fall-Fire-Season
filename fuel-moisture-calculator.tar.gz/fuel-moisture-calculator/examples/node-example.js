// Example: Using fuel-calculator.js in Node.js
// Run with: node examples/node-example.js

const fs = require('fs');

// Load the calculator
const code = fs.readFileSync('./fuel-calculator.js', 'utf8');
eval(code);

console.log('=== Fuel Moisture Calculator - Node.js Example ===\n');

// Example 1: Basic EMC calculation
console.log('Example 1: EMC Calculation');
console.log('----------------------------');
const emc1 = computeEMC(85, 25);
console.log(`Hot & Dry (85°F, 25% RH): ${emc1}% EMC`);

const emc2 = computeEMC(50, 80);
console.log(`Cool & Humid (50°F, 80% RH): ${emc2}% EMC\n`);

// Example 2: Time-lag drying
console.log('Example 2: Time-Lag Drying Model');
console.log('--------------------------------');
console.log('Initial moisture: 20%, Target EMC: 5%, Duration: 6 hours');
const m1 = stepMoisture(20, 5, 6, 1);
const m10 = stepMoisture(20, 5, 6, 10);
console.log(`1-hour fuel: ${m1}% (fast response)`);
console.log(`10-hour fuel: ${m10}% (slow response)\n`);

// Example 3: Multi-day forecast
console.log('Example 3: Multi-Day Fire Weather Forecast');
console.log('------------------------------------------');
const forecast = [
  { label: 'Monday', temp: 65, rh: 55, wind: 5, hours: 12 },
  { label: 'Tuesday', temp: 72, rh: 40, wind: 8, hours: 12 },
  { label: 'Wednesday', temp: 80, rh: 28, wind: 12, hours: 12 },
  { label: 'Thursday', temp: 85, rh: 20, wind: 15, hours: 12 }
];

const results = runModel(12, 15, forecast);

console.log('Starting conditions:');
console.log(`  1-hr fuel: ${results.initial1hr}%`);
console.log(`  10-hr fuel: ${results.initial10hr}%\n`);

console.log('Daily progression:');
results.dailyResults.forEach(day => {
  const critical = day.moisture1Hr <= 6 ? ' ⚠️ CRITICAL' : '';
  console.log(`  ${day.day}: ${day.temp}°F, ${day.rh}% RH → 1hr:${day.moisture1Hr}%, 10hr:${day.moisture10Hr}%${critical}`);
});

console.log('\nForecast summary:');
console.log(`  Final 1-hr moisture: ${results.summary.final1Hr}%`);
console.log(`  Final 10-hr moisture: ${results.summary.final10Hr}%`);
if (results.summary.firstCritical1HrDay) {
  console.log(`  🔥 First critical day: ${results.summary.firstCritical1HrDay}`);
} else {
  console.log(`  ✓ No critical conditions reached`);
}

// Example 4: Edge cases and validation
console.log('\n\nExample 4: Input Validation & Edge Cases');
console.log('----------------------------------------');
console.log('Testing robust input handling:');

// Test with invalid inputs
const emc_invalid = computeEMC('', '');
console.log(`  Empty strings: ${emc_invalid}% (uses defaults: 70°F, 50% RH)`);

// Test with zero values (should be preserved)
const results_zero = runModel(0, 0, [{ temp: 70, rh: 40, wind: 0, hours: 0 }]);
console.log(`  Zero initial values: 1hr=${results_zero.initial1hr}%, 10hr=${results_zero.initial10hr}% (preserved)`);
console.log(`  Zero wind: ${results_zero.dailyResults[0].wind} mph (preserved)`);

// Test with out-of-range RH (should clamp)
const emc_clamp = computeEMC(70, 150);
console.log(`  RH=150% (invalid): ${emc_clamp}% (clamped to 100%)`);

console.log('\n✓ All examples completed successfully!');
