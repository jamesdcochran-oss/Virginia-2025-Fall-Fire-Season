# Setup Instructions for Standalone Repository

This document explains how to create and publish the Fuel Moisture Calculator as a standalone repository.

## Quick Setup

All files for the standalone repository have been prepared in `/tmp/fuel-moisture-calculator/`.

### Step 1: Create New GitHub Repository

1. Go to https://github.com/new
2. Repository name: `fuel-moisture-calculator`
3. Description: "Robust JavaScript library for calculating fuel moisture content using EMC and time-lag models for fire weather forecasting"
4. Choose: Public
5. **DO NOT** initialize with README, .gitignore, or license (we have these files)
6. Click "Create repository"

### Step 2: Initialize and Push

```bash
cd /tmp/fuel-moisture-calculator

# Initialize git repository
git init
git add .
git commit -m "Initial commit: Fuel Moisture Calculator v1.0.0"

# Add remote (replace YOUR_USERNAME with your GitHub username)
git remote add origin https://github.com/YOUR_USERNAME/fuel-moisture-calculator.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### Step 3: Configure GitHub Repository

1. Go to your repository settings
2. Under "About" (right sidebar), add:
   - Description: "Robust JavaScript library for fire weather fuel moisture calculations"
   - Website: Leave blank or add GitHub Pages URL
   - Topics: `fire-weather`, `fuel-moisture`, `wildfire`, `javascript`, `emc`, `nfdrs`, `meteorology`

3. Enable GitHub Pages (optional):
   - Settings → Pages
   - Source: Deploy from branch
   - Branch: main, folder: / (root)
   - Save
   - Your demo will be available at: `https://YOUR_USERNAME.github.io/fuel-moisture-calculator/`

### Step 4: Create Initial Release

```bash
# Tag the first release
git tag -a v1.0.0 -m "Release v1.0.0 - Initial standalone release"
git push origin v1.0.0
```

Then on GitHub:
1. Go to "Releases"
2. Click "Draft a new release"
3. Choose tag: v1.0.0
4. Release title: "v1.0.0 - Initial Release"
5. Description:
   ```
   Initial standalone release of the Fuel Moisture Calculator.
   
   ## Features
   - Robust EMC calculation
   - Time-lag drying model
   - Multi-day forecast modeling
   - Browser and Node.js support
   - Zero dependencies
   - Comprehensive input validation
   
   ## Files
   - `fuel-calculator.js` - Main library
   - `index.html` - Demo page
   - `fuel-calculator-test.html` - Test suite
   ```
6. Click "Publish release"

## Repository Structure

```
fuel-moisture-calculator/
├── .github/
│   └── workflows/
│       └── test.yml           # GitHub Actions CI
├── examples/
│   └── node-example.js        # Node.js usage examples
├── .gitignore                 # Git ignore file
├── CONTRIBUTING.md            # Contribution guidelines
├── LICENSE                    # MIT License
├── README.md                  # Main documentation
├── fuel-calculator.js         # Main library
├── fuel-calculator-test.html  # Browser test suite
├── index.html                 # Demo page
└── package.json               # NPM package info
```

## Linking from Original Repository

To link to this standalone repo from the Virginia Fire Weather repository:

1. Add to your main repository's README:
   ```markdown
   ## Fuel Moisture Calculator
   
   The fuel moisture calculator has been extracted into a standalone library:
   📦 [fuel-moisture-calculator](https://github.com/YOUR_USERNAME/fuel-moisture-calculator)
   ```

2. Update `fuel-calculator.js` in the original repo to reference the standalone version:
   ```javascript
   // This file is maintained in a standalone repository:
   // https://github.com/YOUR_USERNAME/fuel-moisture-calculator
   // 
   // For documentation and updates, see the standalone repo.
   ```

## Publishing to NPM (Optional)

If you want to publish to npm:

```bash
cd /tmp/fuel-moisture-calculator

# Login to npm (if not already)
npm login

# Publish (make sure package name is available)
npm publish
```

Then users can install with:
```bash
npm install fuel-moisture-calculator
```

## Using as a Git Submodule (Alternative)

Instead of copying files, you can use the standalone repo as a submodule:

```bash
cd /path/to/Virginia-2025-Fall-Fire-Season

# Remove existing files
git rm fuel-calculator.js fuel-calculator-test.html

# Add as submodule
git submodule add https://github.com/YOUR_USERNAME/fuel-moisture-calculator.git fuel-calculator

# Commit the change
git commit -m "Replace fuel calculator with submodule link"
```

Then update your HTML to reference:
```html
<script src="fuel-calculator/fuel-calculator.js"></script>
```

## CDN Usage (via jsDelivr)

Once published to GitHub, users can link directly via CDN:

```html
<!-- Latest version -->
<script src="https://cdn.jsdelivr.net/gh/YOUR_USERNAME/fuel-moisture-calculator@main/fuel-calculator.js"></script>

<!-- Specific version (recommended for production) -->
<script src="https://cdn.jsdelivr.net/gh/YOUR_USERNAME/fuel-moisture-calculator@v1.0.0/fuel-calculator.js"></script>
```

## Next Steps

1. ✅ Create GitHub repository
2. ✅ Push code
3. ✅ Configure repository settings
4. ✅ Create v1.0.0 release
5. ⬜ Add to your README in main repository
6. ⬜ (Optional) Publish to NPM
7. ⬜ (Optional) Convert to submodule in main repo

## Support

For issues or questions about the standalone repository:
- Open an issue at: https://github.com/YOUR_USERNAME/fuel-moisture-calculator/issues
