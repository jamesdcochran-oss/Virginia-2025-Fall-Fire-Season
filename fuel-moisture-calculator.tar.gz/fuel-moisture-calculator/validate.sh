#!/bin/bash
# Validation script for standalone repository

echo "🔍 Validating Fuel Moisture Calculator Repository..."
echo

# Check all required files exist
echo "✓ Checking required files..."
files=(
  "fuel-calculator.js"
  "fuel-calculator-test.html"
  "index.html"
  "README.md"
  "LICENSE"
  "CONTRIBUTING.md"
  "SETUP.md"
  "package.json"
  ".gitignore"
  ".github/workflows/test.yml"
  "examples/node-example.js"
)

for file in "${files[@]}"; do
  if [ -f "$file" ]; then
    echo "  ✓ $file"
  else
    echo "  ✗ $file (missing)"
    exit 1
  fi
done

echo
echo "✓ Testing Node.js example..."
node examples/node-example.js > /dev/null 2>&1
if [ $? -eq 0 ]; then
  echo "  ✓ Node.js example runs successfully"
else
  echo "  ✗ Node.js example failed"
  exit 1
fi

echo
echo "✓ Testing library API..."
node -e "
  const fs = require('fs');
  eval(fs.readFileSync('fuel-calculator.js', 'utf8'));
  if (typeof computeEMC !== 'function') throw new Error('computeEMC missing');
  if (typeof stepMoisture !== 'function') throw new Error('stepMoisture missing');
  if (typeof runModel !== 'function') throw new Error('runModel missing');
  console.log('  ✓ All API functions present');
" || exit 1

echo
echo "✓ Testing edge cases..."
node -e "
  const fs = require('fs');
  eval(fs.readFileSync('fuel-calculator.js', 'utf8'));
  
  // Test zero preservation
  const r = runModel(0, 0, [{temp:70,rh:40,wind:0,hours:0}]);
  if (r.initial1hr !== 0) throw new Error('Zero not preserved');
  
  // Test invalid inputs
  const emc = computeEMC('', '');
  if (!Number.isFinite(emc)) throw new Error('Invalid input failed');
  
  console.log('  ✓ Zero values preserved');
  console.log('  ✓ Invalid inputs handled');
" || exit 1

echo
echo "✓ Checking package.json..."
node -e "
  const pkg = require('./package.json');
  if (!pkg.name) throw new Error('Missing package name');
  if (!pkg.version) throw new Error('Missing version');
  if (!pkg.license) throw new Error('Missing license');
  console.log('  ✓ Package: ' + pkg.name + ' v' + pkg.version);
  console.log('  ✓ License: ' + pkg.license);
" || exit 1

echo
echo "📊 Repository Statistics:"
echo "  Files: $(find . -type f ! -path './.git/*' | wc -l)"
echo "  Size: $(du -sh . | cut -f1)"
echo "  Lines (JS): $(wc -l fuel-calculator.js | awk '{print $1}')"
echo

echo "✅ All validation checks passed!"
echo
echo "📦 Ready to publish:"
echo "  1. Create GitHub repository"
echo "  2. git init && git add . && git commit -m 'Initial commit'"
echo "  3. git remote add origin <repo-url>"
echo "  4. git push -u origin main"
echo "  5. git tag -a v1.0.0 -m 'v1.0.0' && git push origin v1.0.0"
