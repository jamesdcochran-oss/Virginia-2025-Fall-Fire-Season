# Fuel Moisture Calculator

A robust, standalone JavaScript library for calculating fuel moisture content using equilibrium moisture content (EMC) and time-lag drying models. Commonly used in fire weather forecasting and wildfire risk assessment.

![Test Suite](https://github.com/user-attachments/assets/a34342e5-fb13-4195-b9fb-07f22fe64136)

## Features

- **Robust Input Handling**: Uses `safeParse()` to handle invalid inputs, NaN values, and preserve valid zeros
- **EMC Calculation**: Empirical approximation used in NFDRS (National Fire Danger Rating System)
- **Time-Lag Modeling**: Exponential decay model for 1-hour and 10-hour fuel moisture
- **Browser and Node.js Compatible**: Works in both browser and non-browser environments
- **Zero Dependencies**: Pure JavaScript with no external dependencies
- **Defensive Programming**: Guards against division by zero, invalid ranges, and missing DOM elements

## Quick Start

### Browser Usage

```html
<!DOCTYPE html>
<html>
<head>
  <title>Fuel Moisture Calculator</title>
</head>
<body>
  <script src="fuel-calculator.js"></script>
  <script>
    // Calculate EMC
    const emc = computeEMC(85, 25); // temp=85°F, rh=25%
    console.log('EMC:', emc); // ~4.1%

    // Calculate fuel moisture after drying
    const moisture = stepMoisture(15, emc, 12, 1);
    console.log('1-hr fuel moisture:', moisture);

    // Run full model
    const results = runModel(10, 12, [
      { temp: 85, rh: 25, wind: 10, hours: 12 },
      { temp: 90, rh: 20, wind: 15, hours: 12 }
    ]);
    console.log('Results:', results);
  </script>
</body>
</html>
```

### Node.js Usage

```javascript
const fs = require('fs');
const code = fs.readFileSync('./fuel-calculator.js', 'utf8');
eval(code);

// Calculate EMC
const emc = computeEMC(85, 25);
console.log('EMC:', emc);

// Run model
const results = runModel(10, 12, [
  { temp: 85, rh: 25, wind: 10, hours: 12 }
]);
console.log(results);
```

## API Reference

### `computeEMC(tempF, rh)`

Computes Equilibrium Moisture Content using empirical approximation.

**Parameters:**
- `tempF` (number): Temperature in Fahrenheit (defaults to 70°F if invalid)
- `rh` (number): Relative humidity percentage (defaults to 50%, clamped to 0-100)

**Returns:** (number) EMC percentage with one decimal place, minimum 0.1%

**Example:**
```javascript
const emc = computeEMC(85, 25); // Returns ~4.1
```

### `stepMoisture(initial, emc, hours, timeLag)`

Models fuel moisture change over time using exponential decay.

**Parameters:**
- `initial` (number): Initial fuel moisture percentage (defaults to emc if invalid)
- `emc` (number): Target equilibrium moisture content (defaults to 5% if invalid)
- `hours` (number): Drying/wetting duration in hours (defaults to 0 if invalid)
- `timeLag` (number): Fuel time-lag constant (1 for 1-hr fuels, 10 for 10-hr fuels; minimum 0.0001)

**Returns:** (number) Final fuel moisture percentage with one decimal place

**Example:**
```javascript
const moisture = stepMoisture(20, 5, 6, 1); // 20% initial, drying to 5% EMC over 6 hours
```

### `runModel(initial1hr, initial10hr, forecastEntries)`

Runs fuel moisture model over multiple forecast periods.

**Parameters:**
- `initial1hr` (number): Initial 1-hour fuel moisture (defaults to 8%)
- `initial10hr` (number): Initial 10-hour fuel moisture (defaults to 10%)
- `forecastEntries` (array): Array of forecast objects with properties:
  - `label` (string, optional): Day label (e.g., "Day 1")
  - `temp` (number): Temperature in °F (defaults to 70°F)
  - `rh` (number): Relative humidity % (defaults to 50%)
  - `wind` (number): Wind speed in mph (defaults to 0)
  - `hours` (number): Drying hours (defaults to 12, min 0)

**Returns:** (object) Results object with:
```javascript
{
  initial1hr: number,
  initial10hr: number,
  dailyResults: [
    {
      day: string,
      temp: number,
      rh: number,
      wind: number,
      hours: number,
      moisture1Hr: number,
      moisture10Hr: number
    }
  ],
  summary: {
    firstCritical1HrDay: string | null,  // First day when 1-hr ≤ 6%
    final1Hr: number,
    final10Hr: number
  }
}
```

**Example:**
```javascript
const results = runModel(10, 12, [
  { label: "Monday", temp: 85, rh: 25, wind: 10, hours: 12 },
  { label: "Tuesday", temp: 90, rh: 20, wind: 15, hours: 12 }
]);

console.log(results.summary.firstCritical1HrDay); // "Monday" if critical
console.log(results.summary.final1Hr); // Final 1-hr moisture
```

## Critical Moisture Thresholds

The model identifies critical fire weather conditions when:
- **1-hour fuel moisture ≤ 6%**: Indicates fine fuels are critically dry
- Fire weather forecasters use these thresholds to issue warnings

## Test Suite

Open `fuel-calculator-test.html` in a browser to run the comprehensive test suite, which includes:
- EMC calculation validation against NFDRS standards
- Time-lag drying model verification
- Real-world Virginia fire weather scenarios
- Critical condition detection tests

## Examples

### Example 1: Simple EMC Calculation
```javascript
// Hot, dry conditions
const criticalEMC = computeEMC(95, 15); // ~0.1%

// Cool, humid conditions  
const safeEMC = computeEMC(50, 80); // ~16.8%
```

### Example 2: Multi-Day Forecast
```javascript
const forecast = runModel(15, 18, [
  { label: "Day 1", temp: 55, rh: 65, wind: 5, hours: 12 },
  { label: "Day 2", temp: 68, rh: 45, wind: 8, hours: 12 },
  { label: "Day 3", temp: 75, rh: 30, wind: 12, hours: 12 },
  { label: "Day 4", temp: 80, rh: 22, wind: 15, hours: 12 }
]);

if (forecast.summary.firstCritical1HrDay) {
  console.log(`⚠️ Critical drying on ${forecast.summary.firstCritical1HrDay}`);
}
```

### Example 3: Embedded in a Web Page

See the included `fuel-calculator-test.html` for a complete example with UI.

## Technical Details

### EMC Formula

The calculator uses an empirical approximation commonly employed in fire weather tools:

```
EMC = 0.942 × RH^0.679 + 11 × e^((RH-100)/10) + 0.18 × (21.1 - T) × (1 - e^(-0.115×RH))
```

Where:
- `EMC` = Equilibrium Moisture Content (%)
- `RH` = Relative Humidity (%, clamped to 0-100)
- `T` = Temperature (°F)

### Time-Lag Model

Fuel moisture changes exponentially toward EMC:

```
M(t) = EMC + (M₀ - EMC) × e^(-t/τ)
```

Where:
- `M(t)` = Fuel moisture at time t
- `M₀` = Initial fuel moisture
- `EMC` = Equilibrium moisture content
- `t` = Time elapsed (hours)
- `τ` = Time-lag constant (1 for 1-hr fuels, 10 for 10-hr fuels)

### Input Validation

All numeric inputs are validated using `safeParse()`:
- Empty strings → fallback value
- `NaN`, `undefined`, `null` → fallback value
- Valid numbers including `0` → preserved
- Out-of-range values → clamped (e.g., RH to 0-100)

## Browser Compatibility

- Modern browsers (ES6+)
- Internet Explorer 11+ (with polyfills for `Array.from`, `Number.isFinite`)

## Contributing

Contributions are welcome! Please ensure:
- Code follows the defensive programming patterns established
- All inputs are validated with `safeParse()`
- Tests pass in `fuel-calculator-test.html`
- No breaking changes to the public API

## License

MIT License - See LICENSE file for details

## Author

James D. Cochran - Five Forks Fire Weather Project

## Acknowledgments

- EMC formula based on NFDRS (National Fire Danger Rating System)
- Time-lag model follows standard fuel moisture modeling practices
- Developed for Virginia fire weather forecasting
